/*
 * js/import.js — Importação de dados via JSON
 *
 * Responsabilidade: abrir/fechar o modal de importação, validar o JSON
 * colado pelo usuário, fazer deepMerge em D e disparar a re-renderização.
 *
 * Conversa com:
 *   - js/data.js (lê e sobrescreve o objeto global D via deepMerge)
 *   - js/ui.js   (chama applyData() após merge bem-sucedido)
 *   - js/charts.js (initCharts() é chamado indiretamente via applyData→goPage)
 *   - index.html (IDs: jsonModal, jsonInput, jsonErr)
 *
 * Pontos importantes:
 *   - deepMerge é recursivo apenas para objetos planos; arrays são
 *     substituídos inteiros (não fundidos). Isso é intencional: ao
 *     importar D.produtos, o array inteiro é substituído.
 *   - showJsonSchema() preenche o textarea com o schema anotado
 *     para orientar quem for preencher o JSON manualmente.
 *   - Erros de parse são exibidos inline em #jsonErr, sem alert().
 */

function openJsonModal(){document.getElementById('jsonModal').classList.add('open');}
function closeJsonModal(){document.getElementById('jsonModal').classList.remove('open');document.getElementById('jsonErr').textContent='';}
function showJsonSchema(e){
  e.preventDefault();
  const schema={
    periodo:"string",gerado:"string",
    kpis:{score:"string",score_delta:"string",prod_ativos:0,prod_entregues:0,prod_delta:"string",tempo:0,tempo_delta:"string",chamados:0,chamados_delta:"string",chamados_aberto:0,chamados_aberto_delta:"string",dias_abertos_chamados:0,dias_abertos_chamados_delta:"string"},
    analises:{score:"string",prod:"string",tempo:"string",chamados:"string",chamados_aberto:"string",dias_abertos_chamados:"string",scores_atenc:"string",causas_conc:"string",causas_soluc:"string",tabela_crit:"string",tabela_cham:"string",tabela_extr:"string"},
    meses:["string"],
    produtos:[{nome:"string",gestor:"string",scores:["number|null"],chamados:0,dim:"string",crit:1}],
    tendencia:{abertos:[0],concluidos:[0]},
    mediaDias:{data:[0]},
    causas:{labels:["string"],data:[0]}
  };
  document.getElementById('jsonInput').value=JSON.stringify(schema,null,2);
}
function applyJson(){
  const raw=document.getElementById('jsonInput').value.trim();
  const err=document.getElementById('jsonErr');
  try{
    const parsed=JSON.parse(raw);
    D=deepMerge(D,parsed);
    err.textContent='';
    closeJsonModal();
    applyData();
  }catch(e){err.textContent='JSON inválido: '+e.message;}
}
function deepMerge(target,source){
  const out={...target};
  for(const k in source){
    if(source[k]&&typeof source[k]==='object'&&!Array.isArray(source[k])&&typeof target[k]==='object'&&!Array.isArray(target[k])){
      out[k]=deepMerge(target[k],source[k]);
    }else{out[k]=source[k];}
  }
  return out;
}

// ═══════════════════════════════════════
// EMAIL EXPORT
// ═══════════════════════════════════════