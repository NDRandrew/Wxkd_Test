/*
 * js/ui.js — Controle da interface do usuário
 *
 * Responsabilidade: preencher o DOM com os dados de D, controlar a
 * navegação entre páginas (home / boletim), o toggle da sidebar,
 * o toggle de tema e o scroll reveal.
 *
 * Conversa com:
 *   - js/data.js   (lê o objeto global D)
 *   - js/charts.js (chama initCharts() ao navegar para o boletim)
 *   - css/styles.css (manipula classes: .act, .col, .visible, [data-theme])
 *   - index.html   (IDs: bltHeaderSub, kpi-*, ana-*, scoreTbody, sb, main)
 *
 * Pontos importantes:
 *   - applyData() é o único ponto de entrada para atualizar todo o DOM.
 *     Chame-a sempre após modificar D (via importação JSON ou outro meio).
 *   - goPage() também dispara initCharts() para garantir que os canvas
 *     estejam visíveis antes de Chart.js tentar dimensioná-los.
 *   - O tema é persistido em localStorage com a chave 'theme'.
 */


// ─── APPLY DATA TO UI ───
function applyData(){
  // Header
  document.getElementById('bltHeaderSub').textContent=`Referência: ${D.periodo}`;
  // KPIs
  setEl('kpi-score',D.kpis.score);
  setEl('kpi-score-delta',D.kpis.score_delta);
  setEl('kpi-prod-ativos',D.kpis.prod_ativos);
  setEl('kpi-prod-entregues',D.kpis.prod_entregues);
  setEl('kpi-prod-delta',D.kpis.prod_delta);
  setEl('kpi-tempo',D.kpis.tempo);
  setEl('kpi-tempo-delta',D.kpis.tempo_delta);
  setEl('kpi-chamados',D.kpis.chamados);
  setEl('kpi-chamados-delta',D.kpis.chamados_delta);
  setEl('kpi-chamados-aberto',D.kpis.chamados_aberto);
  setEl('kpi-chamados-aberto-delta',D.kpis.chamados_aberto_delta);
  setEl('kpi-dias-chamados-aberto',D.kpis.dias_abertos_chamados);
  setEl('kpi-dias-chamados-aberto-delta',D.kpis.dias_abertos_chamados_delta);
  // Analises
  const anaMap={
    'ana-score':'score','ana-prod':'prod','ana-tempo':'tempo','ana-chamados':'chamados','ana-chamados-aberto':'chamados_aberto','ana-dias-chamados':'dias_abertos_chamados',
    'ana-scores-atenc':'scores_atenc',
    'ana-causas-conc':'causas_conc','ana-causas-resol':'causas_soluc',
    'ana-tabela-crit':'tabela_crit','ana-tabela-cham':'tabela_cham', 'ana-tabela-extr':'tabela_extr'
  };
  Object.entries(anaMap).forEach(([id,key])=>setEl(id,D.analises[key]||''));
  // Table
  buildScoreTable();
  // Charts
  initCharts();
}
function setEl(id,val){const e=document.getElementById(id);if(e)e.innerHTML=val;}

// ─── NAV ───
function goPage(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('act'));
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('act'));
  document.getElementById('page-'+id).classList.add('act');
  document.getElementById('nav-'+id).classList.add('act');
  if(id==='blt') initCharts();
}
function toggleSB(){
  document.getElementById('sb').classList.toggle('col');
  document.getElementById('main').classList.toggle('col');
}

// ─── THEME ───
function toggleTheme(){
  const h=document.documentElement;
  h.dataset.theme=h.dataset.theme==='dark'?'light':'dark';
  localStorage.setItem('theme',h.dataset.theme);
  setTimeout(initCharts,80);
}
(()=>{const t=localStorage.getItem('theme');if(t)document.documentElement.dataset.theme=t;})();

// ─── SCROLL REVEAL ───
const ro=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible');});},{threshold:0.06});
document.querySelectorAll('.reveal').forEach(el=>ro.observe(el));