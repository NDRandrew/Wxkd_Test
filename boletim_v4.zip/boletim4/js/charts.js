/*
 * js/charts.js — Renderização de gráficos e tabela de scores
 */

// ─── CONSTANTES DE CHART (disponíveis globalmente) ───
const baseFont     = {family:"'DM Sans', sans-serif", size:11};
const gridColor    = () => getComputedStyle(document.documentElement).getPropertyValue('--g200').trim() || '#E2E4EA';
const textColor    = () => getComputedStyle(document.documentElement).getPropertyValue('--g600').trim() || '#5C6180';
const chartInstances = {};
function destroyChart(id){ if(chartInstances[id]){ chartInstances[id].destroy(); delete chartInstances[id]; } }
function getCtx(id){ const el=document.getElementById(id); if(!el) return null; destroyChart(id); return el.getContext('2d'); }

// ─── CHARTS ───
function initCharts(){
  buildCausasChart();
}

function buildCausasChart(){
  const ctx=getCtx('cCausas'); if(!ctx) return;
  const total=D.causas.data.reduce((a,b)=>a+b,0);
  const clrs=['#0c2a6e','#1f4a8a','#3567a5','#4f83bf','#6a9fd6','#87b9ea','#90c0ee','#99c7f1','#a2cef4','#abd5f7'];
  const sorted=[...D.causas.labels.map((l,i)=>({l,v:D.causas.data[i],c:clrs[i%clrs.length]}))].sort((a,b)=>b.v-a.v);

  chartInstances['cCausas']=new Chart(ctx,{
    type:'bar',
    data:{
      labels:sorted.map(x=>x.l),
      datasets:[{
        data:sorted.map(x=>x.v),
        backgroundColor:sorted.map(x=>x.c),
        borderRadius:6,borderSkipped:false,barThickness:20
      }]
    },
    options:{
      indexAxis:'y',responsive:true,maintainAspectRatio:false,
      layout:{padding:{right:56}},
      plugins:{
        legend:{display:false},
        datalabels:{
          anchor:'end',align:'end',
          formatter:(v)=>{ const pct=((v/total)*100).toFixed(0); return v+' ('+pct+'%)'; },
          font:{size:10,weight:'700',family:"'DM Sans',sans-serif"},
          color:textColor,padding:{left:4}
        }
      },
      scales:{
        x:{ticks:{font:baseFont,color:textColor},grid:{color:gridColor()}},
        y:{ticks:{font:{...baseFont,size:10},color:textColor},grid:{display:false}}
      }
    }
  });

  const leg=document.getElementById('legCausas');
  if(leg){
    leg.innerHTML=sorted.map(x=>{
      const pct=((x.v/total)*100).toFixed(0);
      return `<div class="legend-item"><div class="legend-dot" style="background:${x.c}"></div>${x.l}: <strong style="margin-left:3px">${x.v}</strong>&nbsp;<span style="color:var(--g500);font-size:.66rem">(${pct}%)</span></div>`;
    }).join('');
  }
}

function buildScoreChart(){
  const ctx=getCtx('cScores'); if(!ctx) return;
  const labels=D.produtos.map(p=>p.nome.length>22?p.nome.slice(0,22)+'…':p.nome);
  const scores=D.produtos.map(p=>p.scores[4]||p.scores[3]||0);
  chartInstances['cScores']=new Chart(ctx,{
    type:'bar',
    data:{labels,datasets:[{
      label:'Score Abr/26',data:scores,
      backgroundColor:scores.map(s=>s>=95?'rgba(0,192,122,.75)':s>=85?'rgba(245,166,35,.75)':'rgba(204,10,47,.75)'),
      borderRadius:6,borderSkipped:false,barThickness:20
    }]},
    options:{
      indexAxis:'y',responsive:true,maintainAspectRatio:false,
      layout:{padding:{right:42}},
      plugins:{
        legend:{display:false},
        datalabels:{anchor:'end',align:'end',font:{size:10,weight:'700'},
          formatter:v=>v?v.toFixed(1)+'%':'—',color:textColor,padding:{left:2}}
      },
      scales:{
        x:{min:60,max:100,ticks:{callback:v=>v+'%',font:baseFont,color:textColor},grid:{color:gridColor()}},
        y:{ticks:{font:{...baseFont,size:10},color:textColor},grid:{display:false}}
      }
    }
  });
}

function buildScoreTable(){
  const tbody=document.getElementById('scoreTbody'); if(!tbody) return;
  tbody.innerHTML=D.produtos.map(p=>{
    const abr=p.scores[0],mar=p.scores[1];
    const trend=(!abr||!mar)?'—':(abr>mar?'<span class="trend-arrow" style="color:var(--green)">▲</span>':abr<mar?'<span class="trend-arrow" style="color:var(--red)">▼</span>':'<span style="color:var(--g500)">→</span>');
    const scoreClass=!mar?'':mar>=95?'score-great':mar>=85?'score-warn':'score-bad';
    const scoreClassMAI=!abr?'':abr>=95?'score-great':abr>=85?'score-warn':'score-bad';
    const critDot=p.crit===3?'<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--red)"></span>':p.crit===2?'<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--yellow)"></span>':'<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--green)"></span>';
    const critLbl=p.crit===3?'<span style="display:inline-block;color:var(--red)">Alta</span>':p.crit===2?'<span style="display:inline-block;color:var(--yellow)">Média</span>':'<span style="display:inline-block;color:var(--green)">Baixa</span>';
    return `<tr><td style="text-align:center;width:20px;padding:2px">${critDot}&nbsp;${critLbl}</td><td><strong>${p.nome}</strong></td><td style="font-size:.75rem;color:var(--g600)">${p.gestor}</td><td><span class="badge-score ${scoreClass}">${mar?mar.toFixed(2)+'%':'—'}</span></td><td style="font-size:.78rem"><span class="badge-score ${scoreClassMAI}">${abr?abr.toFixed(2)+'%':'—'}</span></td><td style="text-align:center">${trend}</td><td style="font-size:.78rem">${p.chamados}</td><td style="font-size:.72rem;color:var(--g500)">${p.dim}</td></tr>`;
  }).join('');
}
