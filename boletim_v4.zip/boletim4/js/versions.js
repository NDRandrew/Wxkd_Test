/*
 * js/versions.js — Sistema de versionamento e backup do boletim
 * Sessões 2 + 8 — IMPLEMENTAÇÃO COMPLETA
 */

window.Versions = (() => {
  const KEY      = 'boletim-versions';
  const MAX_AUTO = 10;

  // ── Persistência ─────────────────────────────────────────────────────────

  function load() {
    try { return JSON.parse(localStorage.getItem(KEY) || '[]'); }
    catch { return []; }
  }

  function persist(list) {
    try { localStorage.setItem(KEY, JSON.stringify(list)); }
    catch {
      // localStorage cheio — remover os auto-saves mais antigos e tentar de novo
      const trimmed = list.filter(v => !v.isAutoSave).concat(
        list.filter(v => v.isAutoSave).slice(-3)
      );
      try { localStorage.setItem(KEY, JSON.stringify(trimmed)); }
      catch { /* falha silenciosa */ }
    }
  }

  // ── getStorageUsage ───────────────────────────────────────────────────────

  function getStorageUsage() {
    try {
      let used = 0;
      for (const k in localStorage) {
        if (!Object.prototype.hasOwnProperty.call(localStorage, k)) continue;
        used += (localStorage[k].length + k.length) * 2;
      }
      const total = 5 * 1024 * 1024; // 5 MB estimativa
      return { used, total, percent: Math.min(100, Math.round((used / total) * 100)) };
    } catch {
      return { used: 0, total: 5242880, percent: 0 };
    }
  }

  // ── save ─────────────────────────────────────────────────────────────────

  function save(label, isAutoSave) {
    // Snapshot completo: D + CSS vars + tema
    const root   = document.documentElement;
    const styles = getComputedStyle(root);
    const snapshot = {
      D:    JSON.parse(JSON.stringify(window.D)),
      css:  {
        pr:          root.style.getPropertyValue('--pr')    || '',
        'pr-dk':     root.style.getPropertyValue('--pr-dk') || '',
        fontDisplay: root.style.getPropertyValue('--font-display') || '',
        fontBody:    root.style.getPropertyValue('--font-body')    || ''
      },
      dark: root.dataset.theme === 'dark'
    };

    const entry = {
      id:         Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
      label:      String(label || `Versão ${new Date().toLocaleString('pt-BR')}`).slice(0, 80),
      ts:         new Date().toISOString(),
      isAutoSave: !!isAutoSave,
      snapshot
    };

    const list = load();

    // Limite de auto-saves: manter apenas os MAX_AUTO mais recentes
    if (isAutoSave) {
      const autoSaves = list.filter(v => v.isAutoSave);
      if (autoSaves.length >= MAX_AUTO) {
        autoSaves.sort((a, b) => a.ts.localeCompare(b.ts));
        const oldest = autoSaves[0].id;
        const idx    = list.findIndex(v => v.id === oldest);
        if (idx !== -1) list.splice(idx, 1);
      }
    }

    list.push(entry);
    persist(list);
    DevLog.info('versions.save', `Versão salva: "${entry.label}"${isAutoSave ? ' (auto)' : ''}`);
    return entry.id;
  }

  // ── restore ───────────────────────────────────────────────────────────────

  function restore(id) {
    const entry = load().find(v => v.id === id);
    if (!entry) { DevLog.warn('versions.restore', `ID não encontrado: ${id}`); return false; }

    try {
      const { D: savedD, css, dark } = entry.snapshot;

      // Restaurar D
      Object.assign(window.D, JSON.parse(JSON.stringify(savedD)));

      // Restaurar variáveis CSS
      const root = document.documentElement;
      if (css.pr)          root.style.setProperty('--pr',           css.pr);
      if (css['pr-dk'])    root.style.setProperty('--pr-dk',        css['pr-dk']);
      if (css.fontDisplay) root.style.setProperty('--font-display', css.fontDisplay);
      if (css.fontBody)    root.style.setProperty('--font-body',    css.fontBody);

      // Restaurar tema
      if (dark !== undefined) root.dataset.theme = dark ? 'dark' : 'light';

      // Atualizar UI
      if (typeof applyData   === 'function') applyData();
      if (typeof initCharts  === 'function') setTimeout(initCharts, 80);

      DevLog.info('versions.restore', `Versão restaurada: "${entry.label}"`);
      return true;
    } catch (err) {
      DevLog.capture('versions.restore', err);
      return false;
    }
  }

  // ── remove / rename ───────────────────────────────────────────────────────

  function remove(id) {
    const list = load().filter(v => v.id !== id);
    persist(list);
  }

  function rename(id, newLabel) {
    const list = load();
    const entry = list.find(v => v.id === id);
    if (entry) {
      entry.label = String(newLabel).slice(0, 80);
      persist(list);
    }
  }

  // ── exportJson ────────────────────────────────────────────────────────────

  function exportJson(id) {
    const entry = load().find(v => v.id === id);
    if (!entry) return;
    const blob = new Blob([JSON.stringify(entry.snapshot.D, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `dados_${(entry.snapshot.D.periodo || 'boletim').replace(/\s+/g,'_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ── renderList ────────────────────────────────────────────────────────────

  function renderList(containerId) {
    const el = document.getElementById(containerId);
    if (!el) return;

    const list = load().slice().reverse(); // mais recente primeiro
    const usage = getStorageUsage();

    if (list.length === 0) {
      el.innerHTML = `
        <div class="dev-empty">Nenhuma versão salva.<br><small>Use o botão acima para salvar a versão atual.</small></div>
        <div class="dev-versions-bar-wrap">
          <div class="dev-versions-bar-label">Uso localStorage: ${(usage.used/1024).toFixed(1)} KB / ~5 MB (${usage.percent}%)</div>
          <div class="dev-versions-bar"><div class="dev-versions-bar-fill" style="width:${usage.percent}%"></div></div>
        </div>`;
      return;
    }

    el.innerHTML = list.map(v => {
      const dt  = new Date(v.ts);
      const ts  = dt.toLocaleDateString('pt-BR') + ' ' + dt.toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' });
      const tag = v.isAutoSave
        ? `<span class="dev-versions-tag auto">AUTO</span>`
        : `<span class="dev-versions-tag manual">MANUAL</span>`;
      return `
        <div class="dev-versions-item" data-id="${v.id}">
          <div class="dev-versions-item-info">
            ${tag}
            <span class="dev-versions-label">${v.label}</span>
            <span class="dev-versions-ts">${ts}</span>
          </div>
          <div class="dev-versions-item-actions">
            <button class="dev-btn ghost" style="font-size:.7rem;padding:0 8px;height:26px" data-action="restore" data-id="${v.id}" title="Restaurar esta versão">↩ Restaurar</button>
            <button class="dev-btn ghost" style="font-size:.7rem;padding:0 8px;height:26px" data-action="export"  data-id="${v.id}" title="Baixar D como JSON">⬇ JSON</button>
            <button class="dev-btn danger" style="font-size:.7rem;padding:0 8px;height:26px" data-action="delete"  data-id="${v.id}" title="Excluir versão">✕</button>
          </div>
        </div>`;
    }).join('') + `
      <div class="dev-versions-bar-wrap">
        <div class="dev-versions-bar-label">Uso localStorage: ${(usage.used/1024).toFixed(1)} KB / ~5 MB (${usage.percent}%)</div>
        <div class="dev-versions-bar"><div class="dev-versions-bar-fill" style="width:${usage.percent}%"></div></div>
      </div>`;

    // Event delegation
    el.addEventListener('click', e => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const id     = btn.dataset.id;
      const action = btn.dataset.action;
      if (action === 'restore') {
        if (confirm('Restaurar esta versão? O estado atual não será salvo automaticamente.')) {
          restore(id);
          renderList(containerId);
        }
      } else if (action === 'export') {
        exportJson(id);
      } else if (action === 'delete') {
        if (confirm('Excluir esta versão permanentemente?')) {
          remove(id);
          renderList(containerId);
        }
      }
    }, { once: true }); // evita acúmulo de listeners em re-renders
  }

  // ── Auto-save ─────────────────────────────────────────────────────────────

  let _autoTimer = null;

  function startAutoSave(ms) {
    stopAutoSave();
    const interval = ms || 5 * 60 * 1000; // padrão: 5 min
    _autoTimer = setInterval(() => {
      save(`Auto-save ${new Date().toLocaleString('pt-BR')}`, true);
    }, interval);
  }

  function stopAutoSave() {
    if (_autoTimer) { clearInterval(_autoTimer); _autoTimer = null; }
  }

  return {
    save, restore, remove, rename,
    exportJson, list: load,
    getStorageUsage, renderList,
    startAutoSave, stopAutoSave
  };
})();
