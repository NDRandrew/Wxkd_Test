/*
 * js/devlog.js — Sistema de log de erros da Dev View
 *
 * Responsabilidade: capturar, auto-resolver quando possível e registrar
 * erros que ocorrem durante a edição. Fornece interface de visualização
 * na aba Log do painel editor.
 *
 * Conversa com:
 *   - js/devview.js   (chama DevLog.capture, DevLog.warn, DevLog.info)
 *   - js/devcharts.js (chama DevLog.capture em erros de gráfico)
 *   - index.html      (#dev-log-list, #dev-log-badge)
 *
 * Pontos importantes:
 *   - DevLog é um singleton IIFE exposto em window.DevLog
 *   - Máximo 200 entradas em localStorage, chave 'boletim-devlog'
 *   - Níveis: 'info', 'warn', 'error', 'resolved'
 *   - DevLog.capture(context, err, fallbackFn) é o ponto principal de uso:
 *     registra o erro como 'resolved', tenta executar fallbackFn
 *   - renderBadge() atualiza o contador visual na aba Log
 */

window.DevLog = (() => {
  const MAX   = 200;
  const KEY   = 'boletim-devlog';
  const LVL   = { info:'info', warn:'warn', error:'error', resolved:'resolved' };

  // ── Persistência ──────────────────────────────────────────────────────────

  function load() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || '[]');
    } catch {
      return [];
    }
  }

  function save(entries) {
    try {
      localStorage.setItem(KEY, JSON.stringify(entries.slice(-MAX)));
    } catch {
      // localStorage cheio — descarta as 20 mais antigas silenciosamente
      try {
        const trimmed = entries.slice(-Math.floor(MAX / 2));
        localStorage.setItem(KEY, JSON.stringify(trimmed));
      } catch { /* falha silenciosa — log não é crítico */ }
    }
  }

  // ── Criação de entradas ────────────────────────────────────────────────────

  function add(level, context, message, detail) {
    const entry = {
      id:      Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
      ts:      new Date().toISOString(),
      level,
      context: String(context).slice(0, 100),
      message: String(message).slice(0, 300),
      detail:  detail ? JSON.stringify(detail).slice(0, 500) : null,
      read:    false
    };
    const entries = load();
    entries.push(entry);
    save(entries);
    renderBadge();
    return entry.id;
  }

  // ── API pública ───────────────────────────────────────────────────────────

  function info(context, message, detail)  { return add(LVL.info,     context, message, detail); }
  function warn(context, message, detail)  { return add(LVL.warn,     context, message, detail); }
  function error(context, message, detail) { return add(LVL.error,    context, message, detail); }

  function capture(context, err, fallbackFn) {
    add(LVL.resolved, context,
      err instanceof Error ? err.message : String(err),
      err instanceof Error ? { stack: (err.stack || '').slice(0, 400) } : null
    );
    if (typeof fallbackFn === 'function') {
      try { fallbackFn(); }
      catch (fallbackErr) {
        // O próprio fallback falhou — registrar mas não propagar
        add(LVL.error, context + '.fallback',
          fallbackErr instanceof Error ? fallbackErr.message : String(fallbackErr),
          null
        );
      }
    }
  }

  function getAll()      { return load(); }
  function getUnread()   { return load().filter(e => !e.read); }

  function markAllRead() {
    const entries = load().map(e => ({ ...e, read: true }));
    save(entries);
    renderBadge();
  }

  function clear() {
    localStorage.removeItem(KEY);
    renderBadge();
  }

  // ── Badge visual ──────────────────────────────────────────────────────────

  function renderBadge() {
    const badge = document.getElementById('dev-log-badge');
    if (!badge) return;
    const count = getUnread().length;
    badge.textContent = count > 99 ? '99+' : String(count);
    badge.style.display = count > 0 ? 'inline-flex' : 'none';
  }

  // ── Renderização da lista (chamada por devview.js) ─────────────────────────

  function renderList(containerId, filter, query) {
    const el = document.getElementById(containerId);
    if (!el) return;
    let entries = load().slice().reverse(); // mais recente primeiro

    if (filter && filter !== 'all') {
      entries = entries.filter(e => e.level === filter);
    }
    if (query) {
      const q = query.toLowerCase();
      entries = entries.filter(e =>
        e.context.toLowerCase().includes(q) ||
        e.message.toLowerCase().includes(q)
      );
    }

    if (entries.length === 0) {
      el.innerHTML = '<div class="dev-log-empty">Nenhuma entrada encontrada.</div>';
      return;
    }

    const LABEL = { info:'INFO', warn:'AVISO', error:'ERRO', resolved:'RESOLVIDO' };
    el.innerHTML = entries.map(e => {
      const dt = new Date(e.ts);
      const ts = dt.toLocaleDateString('pt-BR') + ' ' + dt.toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' });
      return `<div class="dev-log-entry dev-log-lvl-${e.level}${e.read ? '' : ' dev-log-unread'}">
        <div class="dev-log-entry-head">
          <span class="dev-log-badge-lvl">${LABEL[e.level] || e.level.toUpperCase()}</span>
          <span class="dev-log-ts">${ts}</span>
          <span class="dev-log-ctx">${e.context}</span>
        </div>
        <div class="dev-log-msg">${e.message}</div>
        ${e.detail ? `<details class="dev-log-detail"><summary>Detalhe</summary><pre>${e.detail}</pre></details>` : ''}
      </div>`;
    }).join('');
  }

  return { info, warn, error, capture, getAll, getUnread, markAllRead, clear, renderBadge, renderList };
})();
