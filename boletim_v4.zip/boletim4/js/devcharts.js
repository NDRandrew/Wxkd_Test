/*
 * js/devcharts.js — Editor de gráficos da Dev View
 * Sessões 5 + 6 — IMPLEMENTAÇÃO COMPLETA
 */

window.DevCharts = (() => {

  // ── renderTab ─────────────────────────────────────────────────────────────

  function renderTab(containerId) {
    const el = document.getElementById(containerId);
    if (!el) return;
    _renderList(el);
  }

  function _renderList(el) {
    const graficos = (window.D && window.D.graficos) ? window.D.graficos : [];
    el.innerHTML = `
      <div class="dev-section-row">
        <span class="dev-section-title">Gráficos Customizados</span>
        <button id="devChartNew" class="dev-btn primary">+ Novo Gráfico</button>
      </div>
      <div class="dev-sep"></div>
      <div id="devChartList"></div>`;

    const list = el.querySelector('#devChartList');
    if (graficos.length === 0) {
      list.innerHTML = '<div class="dev-empty">Nenhum gráfico customizado ainda.</div>';
    } else {
      list.innerHTML = graficos.map((g, i) => `
        <div class="dev-accordion">
          <div class="dev-accordion-head">
            <span class="dev-accordion-title">${g.titulo || 'Gráfico ' + (i + 1)}</span>
            <div style="display:flex;gap:6px">
              <button class="dev-btn ghost" style="font-size:.7rem;padding:0 8px;height:26px"
                data-chart-edit="${i}">✏ Editar</button>
              <button class="dev-btn danger" style="font-size:.7rem;padding:0 8px;height:26px"
                data-chart-del="${i}">✕</button>
            </div>
          </div>
        </div>`).join('');

      list.querySelectorAll('[data-chart-edit]').forEach(btn => {
        btn.addEventListener('click', () => {
          const idx = parseInt(btn.dataset.chartEdit);
          _openModal(idx, el);
        });
      });
      list.querySelectorAll('[data-chart-del]').forEach(btn => {
        btn.addEventListener('click', () => {
          const idx = parseInt(btn.dataset.chartDel);
          if (confirm('Remover este gráfico?')) {
            window.D.graficos.splice(idx, 1);
            _removeChartDOM(idx);
            _renderList(el);
            DevLog.info('devcharts.delete', `Gráfico ${idx} removido`);
          }
        });
      });
    }

    el.querySelector('#devChartNew').addEventListener('click', () => _openModal(null, el));
  }

  function _removeChartDOM(idx) {
    const sec = document.getElementById('devChart-' + idx);
    if (sec) sec.remove();
    // Re-numerar IDs dos gráficos subsequentes
    window.D.graficos.forEach((g, i) => {
      const oldSec = document.getElementById('devChart-' + (i + 1));
      if (oldSec) oldSec.id = 'devChart-' + i;
    });
  }

  // ── Modal ─────────────────────────────────────────────────────────────────

  function _openModal(idx, listEl) {
    const isNew = idx === null;
    const cfg = isNew
      ? { titulo: '', tipo: 'bar', labels: ['A', 'B', 'C'], series: [{ nome: 'Série 1', dados: [10, 20, 30], cor: '#3B6BF5' }], altura: 300, datalabels: true, legenda: false }
      : JSON.parse(JSON.stringify(window.D.graficos[idx]));

    // Overlay
    const overlay = document.createElement('div');
    overlay.className = 'dev-modal-overlay';
    overlay.innerHTML = `
      <div class="dev-modal" style="width:520px;max-height:80vh;overflow-y:auto">
        <div class="dev-modal-head">
          <span>${isNew ? 'Novo Gráfico' : 'Editar Gráfico'}</span>
          <button class="dev-btn ghost" id="devChartModalClose">✕</button>
        </div>
        <div class="dev-modal-body">
          <!-- Sub-abas -->
          <div class="dev-tabs" id="devChartSubTabs">
            <button class="dev-tab-btn act" data-subtab="dados">Dados</button>
            <button class="dev-tab-btn"     data-subtab="series">Séries</button>
            <button class="dev-tab-btn"     data-subtab="visual">Visual</button>
          </div>

          <div id="devChartPane-dados"  class="dev-chart-subpane"></div>
          <div id="devChartPane-series" class="dev-chart-subpane" style="display:none"></div>
          <div id="devChartPane-visual" class="dev-chart-subpane" style="display:none"></div>

          <div class="dev-sep" style="margin-top:16px"></div>
          <div style="display:flex;justify-content:flex-end;gap:8px">
            <button class="dev-btn ghost"   id="devChartCancel">Cancelar</button>
            <button class="dev-btn primary" id="devChartSave">Aplicar</button>
          </div>
        </div>
      </div>`;

    document.body.appendChild(overlay);
    _renderSubTabDados(cfg);
    _renderSubTabSeries(cfg);
    _renderSubTabVisual(cfg);

    // Sub-tab switching
    overlay.querySelectorAll('[data-subtab]').forEach(btn => {
      btn.addEventListener('click', () => {
        overlay.querySelectorAll('[data-subtab]').forEach(b => b.classList.remove('act'));
        btn.classList.add('act');
        overlay.querySelectorAll('.dev-chart-subpane').forEach(p => p.style.display = 'none');
        overlay.querySelector('#devChartPane-' + btn.dataset.subtab).style.display = '';
      });
    });

    overlay.querySelector('#devChartModalClose').addEventListener('click', () => overlay.remove());
    overlay.querySelector('#devChartCancel').addEventListener('click',     () => overlay.remove());

    overlay.querySelector('#devChartSave').addEventListener('click', () => {
      _collectFromModal(cfg, overlay);
      if (!window.D.graficos) window.D.graficos = [];
      if (isNew) {
        window.D.graficos.push(cfg);
        renderChartFromConfig(cfg, window.D.graficos.length - 1);
      } else {
        Object.assign(window.D.graficos[idx], cfg);
        _refreshChartDOM(cfg, idx);
      }
      overlay.remove();
      _renderList(listEl);
      DevLog.info('devcharts.save', `Gráfico "${cfg.titulo}" ${isNew ? 'criado' : 'atualizado'}`);
    });
  }

  function _renderSubTabDados(cfg) {
    const pane = document.getElementById('devChartPane-dados');
    pane.innerHTML = `
      <div class="dev-field">
        <div class="dev-field-label">Título</div>
        <input class="dev-field-input" id="dcTitulo" value="${cfg.titulo || ''}" style="width:100%">
      </div>
      <div class="dev-field">
        <div class="dev-field-label">Tipo</div>
        <select class="dev-field-select" id="dcTipo" style="width:100%">
          <option value="bar"          ${cfg.tipo==='bar'?'selected':''}>Barras verticais</option>
          <option value="horizontalBar"${cfg.tipo==='horizontalBar'?'selected':''}>Barras horizontais</option>
          <option value="line"         ${cfg.tipo==='line'?'selected':''}>Linha</option>
          <option value="doughnut"     ${cfg.tipo==='doughnut'?'selected':''}>Rosca</option>
        </select>
      </div>
      <div class="dev-field">
        <div class="dev-field-label">Labels (um por linha)</div>
        <textarea class="dev-field-input" id="dcLabels" rows="4" style="width:100%;resize:vertical">${(cfg.labels||[]).join('\n')}</textarea>
      </div>`;
  }

  function _renderSubTabSeries(cfg) {
    const pane = document.getElementById('devChartPane-series');
    function render() {
      pane.innerHTML = `
        <div class="dev-section-row" style="margin-bottom:8px">
          <span class="dev-section-title">Séries</span>
          <button class="dev-btn ghost" id="dcAddSeries" style="font-size:.7rem">+ Série</button>
        </div>
        ${(cfg.series||[]).map((s, si) => `
          <div class="dev-field" style="border:1px solid var(--g200);border-radius:6px;padding:8px;margin-bottom:8px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
              <input class="dev-field-input" value="${s.nome||''}" placeholder="Nome da série"
                style="flex:1" data-snome="${si}">
              <button class="dev-btn danger" style="font-size:.7rem;padding:0 8px;height:26px"
                data-sdel="${si}">✕</button>
            </div>
            <div class="dev-field-label">Valores (um por linha, mesma ordem dos labels)</div>
            <textarea class="dev-field-input" rows="3" style="width:100%;resize:vertical" data-sdados="${si}">${(s.dados||[]).join('\n')}</textarea>
          </div>`).join('')}`;

      pane.querySelector('#dcAddSeries').addEventListener('click', () => {
        cfg.series.push({ nome: 'Nova Série', dados: (cfg.labels||[]).map(()=>0), cor: '#3B6BF5' });
        render();
      });
      pane.querySelectorAll('[data-sdel]').forEach(btn => {
        btn.addEventListener('click', () => {
          cfg.series.splice(parseInt(btn.dataset.sdel), 1);
          render();
        });
      });
    }
    render();
  }

  function _renderSubTabVisual(cfg) {
    const pane = document.getElementById('devChartPane-visual');
    pane.innerHTML = `
      <div class="dev-field">
        <div class="dev-field-label">Altura (px)</div>
        <input class="dev-field-input" type="number" id="dcAltura" value="${cfg.altura||300}" style="width:100px">
      </div>
      <div class="dev-field" style="display:flex;gap:16px">
        <label style="display:flex;align-items:center;gap:6px;font-size:.78rem;cursor:pointer">
          <input type="checkbox" id="dcDatalabels" ${cfg.datalabels?'checked':''}> Mostrar valores
        </label>
        <label style="display:flex;align-items:center;gap:6px;font-size:.78rem;cursor:pointer">
          <input type="checkbox" id="dcLegenda" ${cfg.legenda?'checked':''}> Legenda
        </label>
      </div>
      <div class="dev-field">
        <div class="dev-field-label">Cores das séries (hex, uma por linha)</div>
        <textarea class="dev-field-input" id="dcCores" rows="4" style="width:100%;resize:vertical">${(cfg.series||[]).map(s=>s.cor||'#3B6BF5').join('\n')}</textarea>
      </div>`;
  }

  function _collectFromModal(cfg, overlay) {
    cfg.titulo     = overlay.querySelector('#dcTitulo').value.trim();
    cfg.tipo       = overlay.querySelector('#dcTipo').value;
    cfg.labels     = overlay.querySelector('#dcLabels').value.split('\n').map(s=>s.trim()).filter(Boolean);
    cfg.altura     = parseInt(overlay.querySelector('#dcAltura').value) || 300;
    cfg.datalabels = overlay.querySelector('#dcDatalabels').checked;
    cfg.legenda    = overlay.querySelector('#dcLegenda').checked;
    const cores    = overlay.querySelector('#dcCores').value.split('\n').map(s=>s.trim());

    // Coletar séries
    overlay.querySelectorAll('[data-snome]').forEach(inp => {
      const si = parseInt(inp.dataset.snome);
      if (cfg.series[si]) cfg.series[si].nome = inp.value;
    });
    overlay.querySelectorAll('[data-sdados]').forEach(ta => {
      const si = parseInt(ta.dataset.sdados);
      if (cfg.series[si]) cfg.series[si].dados = ta.value.split('\n').map(s=>parseFloat(s)||0);
    });
    cfg.series.forEach((s, i) => { if (cores[i]) s.cor = cores[i]; });
  }

  // ── renderChartFromConfig ─────────────────────────────────────────────────

  function renderChartFromConfig(cfg, idx) {
    const body = document.querySelector('.blt-body');
    if (!body) return;

    const secId    = 'devChart-' + idx;
    const canvasId = 'cDevChart-' + idx;

    let sec = document.getElementById(secId);
    if (!sec) {
      sec = document.createElement('section');
      sec.id = secId;
      sec.className = 'reveal visible';
      body.appendChild(sec);
    }

    sec.innerHTML = `
      <div class="sec-hd">
        <div class="sec-hd-bar"></div>
        <div><div class="sec-hd-title">${cfg.titulo || 'Gráfico Customizado'}</div></div>
      </div>
      <div style="position:relative;height:${cfg.altura||300}px">
        <canvas id="${canvasId}"></canvas>
      </div>`;

    try {
      if (window.chartInstances && window.chartInstances[canvasId]) {
        window.chartInstances[canvasId].destroy();
        delete window.chartInstances[canvasId];
      }
      const ctx = document.getElementById(canvasId).getContext('2d');
      const isHoriz = cfg.tipo === 'horizontalBar';
      const type    = (isHoriz || cfg.tipo === 'bar') ? 'bar' : cfg.tipo;

      const datasets = (cfg.series || []).map(s => ({
        label:            s.nome || '',
        data:             s.dados || [],
        backgroundColor: cfg.tipo === 'doughnut'
          ? (cfg.series.map(x => x.cor || '#3B6BF5'))
          : (s.cor || '#3B6BF5'),
        borderRadius: 4
      }));

      const chartCfg = {
        type,
        data: { labels: cfg.labels || [], datasets },
        options: {
          indexAxis: isHoriz ? 'y' : 'x',
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend:     { display: !!cfg.legenda },
            datalabels: cfg.datalabels
              ? { anchor:'end', align:'end', font:{ size:10, weight:'700' }, color: window.textColor ? window.textColor() : '#5C6180' }
              : { display: false }
          },
          scales: cfg.tipo === 'doughnut' ? {} : {
            x: { ticks:{ font: window.baseFont || { family:"'DM Sans',sans-serif", size:11 } }, grid:{ color: window.gridColor ? window.gridColor() : '#E2E4EA' } },
            y: { ticks:{ font: window.baseFont || { family:"'DM Sans',sans-serif", size:11 } }, grid:{ display: false } }
          }
        }
      };

      const inst = new Chart(ctx, chartCfg);
      if (window.chartInstances) window.chartInstances[canvasId] = inst;
    } catch (err) {
      DevLog.capture('devcharts.renderChartFromConfig', err);
    }
  }

  function _refreshChartDOM(cfg, idx) {
    const sec = document.getElementById('devChart-' + idx);
    if (sec) sec.remove();
    renderChartFromConfig(cfg, idx);
  }

  return { renderTab, renderChartFromConfig };
})();
