/*
 * js/data.js — Singleton de dados do boletim
 * Responsabilidade: definir window.D (única fonte de verdade de dados).
 */

Chart.register(ChartDataLabels);

window.D = {
  periodo: "Maio de 2026",
  gerado: "31/05/2026",
  kpis: {
    score: "97.06%", score_delta: "▲ 0.75% vs Abr/26",
    prod_ativos: 87, prod_entregues: 4, prod_delta: "▲ 2 Produtos e 2 Modelos",
    tempo: 9, tempo_delta: "▼ 2 Dias vs Abr/26",
    chamados: 92.83, chamados_delta: "▲ 1771 Cham. vs Abr/26",
    chamados_aberto: 416, chamados_aberto_delta: "&nbsp;",
    dias_abertos_chamados: 8.40, dias_abertos_chamados_delta: "▼ 24,61 Dias vs Abr/26"
  },
  analises: {
    score: "Score em 97,06% com alta de 0,75 pp vs Abril. Tend\u00eancia positiva sustentada pelo crescimento estável de ativos já consolidados podendo dar destaque a <i>Rentabilidade de Investimento BVP</i>, <i> Bradesco Global Solution</i> e <i>Clientes Apostadores</i>, sendo os 3 produtos com maior crescimento.",
    prod: "87 ativos monitorados, 4 entregas no per\u00edodo (2 produtos e 2 modelos). Capacidade de absor\u00e7\u00e3o mantida sem impacto no desempenho.",
    tempo: "Tempo médio de 9 dias (Dev + Homologação + Implantação). Ganho de eficiência operacional no ciclo de entregas impulsionado pelo uso do DEVA e BRAIA4DQ.",
    chamados: "Taxa de Resolu\u00e7\u00e3o de Chamados Histórica em 92,83% Em relação ao Mês de Abril, o desempenho da taxa de resolução é de 79,40%, aproximadamente 13,40 pontos abaixo da média geral.",
    chamados_aberto: "416 chamados fora do  SLA de 5 dias para resolução, recomendamos fortemente priorização imediata da resolução de chamados.",
    dias_abertos_chamados: "Redução do tempo médio de resolução de chamados em 76% (saindo de 33 dias em abril para aproximadamente 8 dias em maio), resultado de um acompanhamento mais próximo do time de qualidade junto às áreas responsáveis.",
    scores_atenc: "Rating PLDTF em 71,43% (\u221215,5 pp vs Abril) \u2014 principal detrator. Pesquisa de Satisfa\u00e7\u00e3o em forte recupera\u00e7\u00e3o (93,3% ap\u00f3s 29,0% em Abril).",
    causas_conc: "Alta concentração de chamados em <strong>Rentabilidade de Investimento</strong>, totalizando 653 chamados gerados no período. O produto representou 54,25% dos casos Job/Malha com Atraso e 48,45% dos casos de Job/Malha com Erro de Execução, além de 15,34% dos casos de Base Origem Indisponível. O cenário é reflexo das alterações e revisões de regras atualmente em implementação.",
    causas_soluc: "Identificado que 23% (Preenchimento Incorreto e Alteração na Estrutura da Tabela ou Rotina) dos casos registrados possuem oportunidade de mitigação",
    tabela_crit: "6 ativos criticidade Baixa, 2 com criticidade Média e 2 com criticidade Alta. PLDTF (crit. Alta) com 71,43% \u2014 abaixo do limiar aceit\u00e1vel de 85%.",
    tabela_cham: "<br><strong>Dados Públicos Socioeconômicos e Demográficos</strong> \u2014 O score do produto segue abaixo do esperado, mesmo com alta de 5,83% no mês. O desvio ocorreu devido a 31 tabelas descalibradas, cujas correções já foram aplicadas e refletem no avanço recente com score de 100% no final de Maio.<br><br><strong>Operação e Repasse FINAME BNDES</strong> \u2014 Impacto negativo de 21,21% gerado por indisponibilidade na camada bronze. Incidente em tratativa, aguardando parecer definitivo da área responsável.<br><br><strong>Rating de Riscos PLDTF</strong> \u2014 Mesmo com evolução de 4,52%, o score permanece abaixo do ideal devido à relevância de Alta Criticidade do produto. O impacto temporário deve-se à remoção de um schema em descontinuação, ação que já está sendo tratada pelo time técnico.<br><br><strong>Rentabilidade de Investimento</strong> \u2014 Com crescimento de 0,67%, o indicador atingiu 88,33%, mantendo-se em aceitável, sendo abaixo do esperado para a média criticidade. O patamar atual reflete a revisão em andamento das regras aplicadas para assegurar o alinhamento ao cenário real das tabelas, alta taxa de chamados atingindo 653 sendo concentrado em Base Indisponível e Job/Malha com Erro de Execução.<br><br><strong>Restritivo</strong> \u2014 Retração de 6,04% em produto de média criticidade devido à instabilidade nos pipelines, que gerou indisponibilidade temporária de dados para consumo. Os tech leads atuaram prontamente na correção e um comunicado oficial foi enviado sobre a manutenção dos processos, já colhendo resultados, estando atualmente 97,03%.",
    tabela_extr: "<br><strong>Kunumi</strong> \u2014 No contexto do Projeto Kunumi, a modernização do monitoramento do Comportamental PJ evolui com mapeamento concluído e ampliação de escopo por meio de IA aplicada à Qualidade de Dados. A curadoria técnica está em fase final, com conclusão prevista para 12/06. Na sequência, a implementação das novas métricas deverá elevar o score do produto. O projeto inclui ainda o expurgo de tabelas obsoletas, conduzido em alinhamento contínuo com os responsáveis pelos dados, reforçando a governança. A entrega completa está estimada para jun/2026.<br><br><strong>CMR - Comprometimento Máximo de Renda</strong> \u2014 Em tratativa realizada em sala de guerra junto à Superintendência, foi identificado que a redução de aproximadamente 2 mil clientes elegíveis decorreu de um desvio na variável de book. A análise de Qualidade de Dados evidenciou um gap de monitoramento, uma vez que o processamento ocorre em camada de trabalho (WKR) sem controle ativo, o que limita a visibilidade e a governança — atualmente restritas às etapas iniciais do fluxo. Como plano de ação, considerando o desligamento do Cloudera previsto para o Q3, será realizado o tombamento das tabelas para cloud. A partir desse movimento, a área de Qualidade de Dados irá estruturar um cronograma para priorização e inclusão das tabelas no processo contínuo de monitoramento."
  },
  meses: ['Mai/26','Abr/26','Mar/26','Fev/26','Jan/26'],
  produtos: [
    {nome:'Dados Publicos Socioeconomicos e Demograficos',gestor:'Controle Integrado de Riscos',scores:[80.43,72.11,68.09,68.30,74.13],chamados:45,dim:'Disponibilidade',crit:1},
    {nome:'Operacao e Repasse FINAME BNDES',gestor:'Controladoria',scores:[99.46,87.66,100.00,100.00,78.79],chamados:3,dim:'Disponibilidade',crit:1},
    {nome:'Rating de Risco PLDTF',gestor:'Segurança Corporativa',scores:[71.43,86.96,80.00,83.33,87.85],chamados:2,dim:'Unicidade',crit:3},
    {nome:'Rentabilidade de Investimento',gestor:'Investimentos',scores:[87.81,88.38,88.18,87.66,88.33],chamados:653,dim:'Consistencia',crit:2},
    {nome:'Autentificacao de Usuarios - Canais Digitais',gestor:'Bradesco Experience',scores:[110.00,110.00,110.00,90.19,92.40],chamados:6,dim:'Completude',crit:1},
    {nome:'Restritivo',gestor:'Credito',scores:[99.82,99.57,100.00,98.98,92.94],chamados:9,dim:'Disponibilidade',crit:2},
    {nome:'Simulador de Metricas de Risco de Contraparte de Derivativos CVA',gestor:'Controle Integrado de Riscos',scores:[110.00,110.00,99.71,92.96,94.89],chamados:42,dim:'Disponibilidade',crit:1}
  ],
  tendencia: {abertos:[1],concluidos:[1]},
  mediaDias: {data:[1]},
  causas: {
    labels:['Base Origem Indisponivel ou Disponibilizada com Atraso','Job/Malha com Erro de Execucao ou Abend','Job/Malha com Atraso','Alteracao na Estrutura da Tabela ou Rotina','Preenchimento Incorreto na Entrada do Dado','Externo (Dependência de Empresas externas)','Problemas com Ambiente (Lentidao/Indisponibilidade/Etc.)','Falha Cluster - subnet_exhausted'],
    data:[202,97,94,86,42,28,7,3]
  },
  graficos: []
};
