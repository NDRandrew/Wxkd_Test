/*
 * js/email.js — Geração e exportação da versão de e-mail
 *
 * Responsabilidade: gerar o HTML table-based do e-mail (compatível com
 * clientes de e-mail), mostrar preview, copiar, baixar como .html e
 * baixar como .png (via html2canvas).
 *
 * Conversa com:
 *   - js/data.js   (lê D para montar o conteúdo do e-mail)
 *   - js/charts.js (lê canvas #cCausas via toDataURL para embutir imagens)
 *   - index.html   (IDs: emailModal, emailPreview, pngStatus, btnPng)
 *   - CDN html2canvas@1.4.1 (carregado em index.html antes deste script)
 *   - DOM live     (lê .release-card, .po-card para não duplicar dados)
 *
 * Pontos importantes:
 *   - O e-mail NÃO usa CSS externo — todo estilo é inline ou em atributos
 *     de tabela, pois clientes de e-mail ignoram <style> externo.
 *   - linear-gradient e border-radius em <td> foram removidos do e-mail
 *     pois não são suportados pelo Outlook.
 *   - Para o PNG funcionar os canvas precisam estar renderizados
 *     (página do boletim aberta). downloadEmailPng() injeta o HTML em
 *     um iframe off-screen, aguarda layout e só então chama html2canvas.
 *   - scale:3 em html2canvas resulta em ~2700px de largura — mesma
 *     qualidade do Playwright HD usado no outro contexto.
 */

function openEmailModal(){
  const html=buildEmailHtml();
  document.getElementById('emailPreview').innerHTML=`<iframe srcdoc="${html.replace(/"/g,'&quot;')}"></iframe>`;
  document.getElementById('emailModal').classList.add('open');
}
function closeEmailModal(){document.getElementById('emailModal').classList.remove('open');}
function copyEmailHtml(){navigator.clipboard.writeText(buildEmailHtml()).then(()=>alert('HTML copiado para a área de transferência!'));}
function downloadEmail(){
  const a=document.createElement('a');
  a.href='data:text/html;charset=utf-8,'+encodeURIComponent(buildEmailHtml());
  a.download=`boletim_email_${D.periodo.replace(/\s/g,'_')}.html`;a.click();
}

function downloadEmailPng(){
  const btn    = document.getElementById('btnPng');
  const status = document.getElementById('pngStatus');

  // ── 1. Write email HTML into a hidden, off-screen iframe ──────────────────
  const html = buildEmailHtml();
  const iframe = document.createElement('iframe');
  // position off-screen so it doesn't flash
  iframe.style.cssText = 'position:fixed;left:-9999px;top:0;border:none;';
  // email is 900px wide — set exactly that so layout is correct
  iframe.width  = '900';
  iframe.height = '1';
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument || iframe.contentWindow.document;
  doc.open(); doc.write(html); doc.close();

  // ── 2. Wait for iframe content to fully render (images + layout) ──────────
  btn.disabled  = true;
  btn.textContent = 'Gerando…';
  status.style.display = 'inline';
  status.textContent   = 'Renderizando — pode levar alguns segundos…';

  // Use requestAnimationFrame + small timeout to let the iframe paint
  setTimeout(() => {
    const iframeDoc  = iframe.contentDocument || iframe.contentWindow.document;
    const fullHeight = iframeDoc.body.scrollHeight || iframeDoc.documentElement.scrollHeight;

    // Resize iframe to full height so nothing is clipped
    iframe.height = fullHeight;

    // Small extra delay to ensure reflow after resize
    setTimeout(() => {
      html2canvas(iframeDoc.body, {
        scale       : 5,          // 3× = ~2700px wide, crisp on any screen
        useCORS     : true,
        allowTaint  : true,
        width       : 900,
        height      : fullHeight,
        windowWidth : 900,
        scrollX     : 0,
        scrollY     : 0,
        backgroundColor: '#ECEEF3'
      }).then(canvas => {
        // Download as PNG
        canvas.toBlob(blob => {
          const url = URL.createObjectURL(blob);
          const a   = document.createElement('a');
          a.href    = url;
          a.download = `boletim_email_${D.periodo.replace(/\s/g,'_')}.png`;
          a.click();
          URL.revokeObjectURL(url);

          // Clean up
          document.body.removeChild(iframe);
          btn.disabled    = false;
          btn.textContent = 'Download PNG';
          status.style.display = 'none';
        }, 'image/png');
      }).catch(err => {
        console.error('html2canvas error:', err);
        document.body.removeChild(iframe);
        btn.disabled    = false;
        btn.textContent = 'Download PNG';
        status.textContent = 'Erro ao gerar imagem. Tente novamente.';
      });
    }, 300);
  }, 600);
}

function buildEmailHtml(){
  // ── Capture charts (only causas — scores chart removed) ─────────────────────
  const causasCanvas = document.getElementById('cCausas');
  const causasImg = causasCanvas ? causasCanvas.toDataURL('image/png') : '';

  // ── Constants ────────────────────────────────────────────────────────────────
  const W   = 900;
  const pad = 40;
  const inner = W - pad * 2; // 820px

  // ── Helpers ──────────────────────────────────────────────────────────────────

  // Section heading — solid left bar, no gradient
  const secHd = (title) =>
    `<tr><td style="padding:0 ${pad}px;background:#ffffff">
       <table width="100%" cellpadding="0" cellspacing="0" border="0">
         <tr><td style="border-top:1px solid #E2E4EA;padding-top:24px;padding-bottom:4px">
           <table cellpadding="0" cellspacing="0" border="0"><tr>
             <td style="width:4px;background:#8C0F3B;font-size:1px;line-height:1px">&nbsp;</td>
             <td style="padding-left:10px;font-size:13px;font-weight:700;color:#1A1D2E;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${title}</td>
           </tr></table>
         </td></tr>
       </table>
     </td></tr>`;

  // Analysis strip — solid bg color, no gradient
  const ana = (color, bgcolor, label, text) =>
    `<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:0"><tr>
      <td style="background:${bgcolor}; border-left:3px solid ${color}; padding:9px 13px">
        <div style="font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:${color};margin-bottom:3px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${label}</div>
        <div style="font-size:11px;color:#5C6180;line-height:1.6;font-style:italic;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${text}</div>
      </td>
    </tr></table>`;



  // Spacer between ana strips
  const anaSpacer = `<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="height:6px;font-size:1px;line-height:1px">&nbsp;</td></tr></table>`;

  // KPI card — solid border-top, no gradient
  const kpiCard = (color, label, value, delta, deltaColor='#8A8FA8') =>
    `<td style="padding:3px;vertical-align:top">
       <table width="100%" cellpadding="0" cellspacing="0" border="0">
         <tr><td style="background:#F4F5F7;padding:0">
           <table width="100%" cellpadding="0" cellspacing="0" border="0">
             <tr><td style="background:${color};height:3px;font-size:1px;line-height:1px">&nbsp;</td></tr>
             <tr><td style="padding:14px 12px">
               <div style="font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${label}</div>
               <div style="font-size:24px;font-weight:800;color:${color};line-height:1;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${value}</div>
               <div style="font-size:10px;color:${deltaColor};margin-top:4px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${delta}</div>
             </td></tr>
           </table>
         </td></tr>
       </table>
     </td>`;

  // ── Table rows ────────────────────────────────────────────────────────────────
  const prodRows = D.produtos.map((p,i) => {
    const a = p.scores[4]||p.scores[3], m = p.scores[3];
    const t    = (!a||!m)?'→':(a>m?'▲':'▼');
    const tClr = (!a||!m)?'#888':(a>m?'#00C07A':'#E8143A');
    const sClr = !a?'#888':a>=95?'#00C07A':a>=85?'#F5A623':'#CC0A2F';
    const mClr = !m?'#888':m>=95?'#00C07A':m>=85?'#F5A623':'#CC0A2F';
    const cClr = p.crit===3?'#E8143A':p.crit===2?'#F5A623':'#00C07A';
    const cLbl = p.crit===3?'Alta':p.crit===2?'Média':'Baixa';
    const nome = p.nome.length>30?p.nome.slice(0,30)+'…':p.nome;
    const bg   = i%2===0?'#ffffff':'#F8F9FB';
    return `<tr style="background:${bg}">
      <td style="padding:8px 10px;border-bottom:1px solid #E2E4EA;white-space:nowrap;font-family:'Segoe UI',Helvetica,Arial,sans-serif">
        <table cellpadding="0" cellspacing="0" border="0"><tr>
          <td><div style="width:8px;height:8px;border-radius:50%;flex-shrink:0;background:${cClr}"></div></td>
          <td style="padding-left:5px;font-size:10px;font-weight:700;color:${cClr}">${cLbl}</td>
        </tr></table>
      </td>
      <td style="padding:8px 10px;font-size:11px;font-weight:700;color:#1A1D2E;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${nome}</td>
      <td style="padding:8px 10px;font-size:10px;color:#8A8FA8;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${p.gestor}</td>
      <td style="padding:8px 10px;text-align:center;border-bottom:1px solid #E2E4EA">
        <table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto"><tr>
          <td style="background:${mClr}20;padding:2px 8px;font-size:10px;font-weight:700;color:${mClr};font-family:'Segoe UI',Helvetica,Arial,sans-serif;white-space:nowrap">${m?m.toFixed(2)+'%':'—'}</td>
        </tr></table>
      </td>
      <td style="padding:8px 10px;text-align:center;border-bottom:1px solid #E2E4EA">
        <table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto"><tr>
          <td style="background:${sClr}20;padding:2px 8px;font-size:10px;font-weight:700;color:${sClr};font-family:'Segoe UI',Helvetica,Arial,sans-serif;white-space:nowrap">${a?a.toFixed(2)+'%':'—'}</td>
        </tr></table>
      </td>
      <td style="padding:8px 10px;font-size:13px;font-weight:800;text-align:center;color:${tClr};border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${t}</td>
      <td style="padding:8px 10px;font-size:11px;text-align:center;color:#5C6180;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${p.chamados}</td>
      <td style="padding:8px 10px;font-size:10px;color:#8A8FA8;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${p.dim}</td>
    </tr>`;
  }).join('');

  // ── Releases ─────────────────────────────────────────────────────────────────
  const buildRelGrid = (section) => {
    const cards = [...section.querySelectorAll('.release-card')].map(rc => {
      const isNew = rc.classList.contains('new');
      const color = isNew ? '#00C07A' : '#3B6BF5';
      const badge = rc.querySelector('.release-badge')?.textContent || '';
      const name  = rc.querySelector('.release-name')?.textContent  || '';
      const ver   = rc.querySelector('.release-ver')?.textContent   || '';
      return {color, badge, name, ver};
    });
    const cols = 3;
    const cw   = Math.floor(inner/cols);
    const rows = [];
    for(let i=0;i<cards.length;i+=cols){
      const chunk = cards.slice(i,i+cols);
      let cells = chunk.map(r =>
        `<td width="${cw}" style="padding:4px;vertical-align:top">
           <table width="100%" cellpadding="0" cellspacing="0" border="0">
             <tr><td style="background:#ffffff;border:1px solid #E2E4EA;padding:0">
               <table width="100%" cellpadding="0" cellspacing="0" border="0">
                 <tr><td style="background:${r.color};height:3px;font-size:1px;line-height:1px">&nbsp;</td></tr>
                 <tr><td style="padding:12px 14px">
                   <table cellpadding="0" cellspacing="0" border="0" style="margin-bottom:7px"><tr>
                     <td style="background:${r.color}22;padding:2px 7px;font-size:8px;font-weight:800;text-transform:uppercase;letter-spacing:.07em;color:${r.color};font-family:'Segoe UI',Helvetica,Arial,sans-serif">${r.badge}</td>
                   </tr></table>
                   <div style="font-size:11px;font-weight:700;color:#1A1D2E;line-height:1.35;margin-bottom:4px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${r.name}</div>
                   <div style="font-size:10px;color:#8A8FA8;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${r.ver}</div>
                 </td></tr>
               </table>
             </td></tr>
           </table>
         </td>`
      ).join('');
      for(let j=chunk.length;j<cols;j++) cells += `<td width="${cw}" style="padding:4px"></td>`;
      rows.push(`<tr>${cells}</tr>`);
    }
    return rows.join('');
  };

  const relSections = document.querySelectorAll('section.reveal');
  let relGrid1=null,relGrid2=null,relTitle1='',relTitle2='';
  relSections.forEach(sec=>{
    const title = sec.querySelector('.sec-hd-title')?.textContent?.trim()||'';
    const grid  = sec.querySelector('.release-grid');
    if(!grid) return;
    if(title.toLowerCase().includes('prevista')){relGrid2=grid;relTitle2=title;}
    else{relGrid1=grid;relTitle1=title;}
  });
  const releaseRows1 = relGrid1?buildRelGrid(relGrid1):'';
  const releaseRows2 = relGrid2?buildRelGrid(relGrid2):'';

  // ── PO cards ─────────────────────────────────────────────────────────────────
  const poCards = [...document.querySelectorAll('.po-card')].map(pc=>{
    const name  = pc.querySelector('.po-name')?.textContent||'';
    const role  = pc.querySelector('.po-role')?.textContent||'';
    const items = [...pc.querySelectorAll('.po-item-content')].map(it=>{
      const tag  = it.querySelector('.po-item-tag')?.textContent||'';
      const ttl  = it.querySelector('.po-item-title')?.textContent||'';
      const desc = it.querySelector('.po-item-desc')?.textContent||'';
      const tagClr = it.querySelector('.po-item-tag')?.classList.contains('tag-struct')?'#c01137':
                     it.querySelector('.po-item-tag')?.classList.contains('tag-init')?'#3B6BF5':
                     it.querySelector('.po-item-tag')?.classList.contains('tag-ops')?'#00C07A':'#7C4DFF';
      return `<tr>
        <td style="width:6px;padding-top:20px;vertical-align:top">
          
        </td>
        <td style="padding-left:8px;padding-bottom:10px;padding-top:10px">
          
          <div style="font-size:11px;font-weight:700;color:#1A1D2E;line-height:1.35;margin-bottom:3px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${ttl}</div>
          <div style="font-size:10px;color:#5C6180;line-height:1.5;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${desc}</div>
        </td>
      </tr>`;
    }).join(`<tr><td colspan="2" style="padding:0 0 0 14px"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="height:1px;background:#E2E4EA;font-size:1px;line-height:1px">&nbsp;</td></tr></table></td></tr>`);
    return {name,role,items};
  });

  const poRows = (()=>{
    const cols=2, cw=Math.floor(inner/cols)-4;
    const rows=[];
    for(let i=0;i<poCards.length;i+=cols){
      const chunk=poCards.slice(i,i+cols);
      const cells=chunk.map(po=>
        `<td width="${cw}" style="padding:4px;vertical-align:top">
           <table width="100%" cellpadding="0" cellspacing="0" border="0">
             <tr><td style="border:1px solid #E2E4EA">
               <table width="100%" cellpadding="0" cellspacing="0" border="0">
                 <tr><td style="background:#F4F5F7;border-bottom:1px solid #E2E4EA;padding:11px 14px">
                   <div style="font-size:12px;font-weight:700;color:#1A1D2E;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${po.name}</div>
                   <div style="font-size:10px;color:#8A8FA8;margin-top:2px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">${po.role}</div>
                 </td></tr>
                 <tr><td style="padding:12px 14px">
                   <table width="100%" cellpadding="0" cellspacing="0" border="0">
                     ${po.items}
                   </table>
                 </td></tr>
               </table>
             </td></tr>
           </table>
         </td>`
      ).join('');
      rows.push(`<tr>${cells}</tr>`);
    }
    return rows.join('');
  })();

  // ── Assemble ──────────────────────────────────────────────────────────────────
  return `<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="UTF-8">
<title>Boletim Qualidade — ${D.periodo}</title>
</head>
<body style="margin:0;padding:0;background:#ECEEF3;font-family:'Segoe UI',Helvetica,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#ECEEF3;padding:28px 0">
<tr><td align="center">
<table width="${W}" cellpadding="0" cellspacing="0" border="0" style="max-width:${W}px;background:#ffffff">

  <!-- HEADER — solid color, no gradient -->
  <tr><td style="background:#8C0F3B;padding:30px ${pad}px 26px">
    <table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td>
      <table cellpadding="0" cellspacing="0" border="0" style="margin-bottom:11px"><tr>
        <td style="border:1px solid rgba(255,255,255,.25);padding:3px 12px;font-size:9px;font-weight:700;color:rgba(255,255,255,.8);text-transform:uppercase;letter-spacing:.1em;font-family:'Segoe UI',Helvetica,Arial,sans-serif">Boletim Mensal · Inteligência de Dados</td>
      </tr></table>
      <div style="font-size:24px;font-weight:800;color:#ffffff;line-height:1.05;margin-bottom:8px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">Boletim de Qualidade de Dados</div>
      <div style="font-size:12px;color:rgba(255,255,255,.65);font-family:'Segoe UI',Helvetica,Arial,sans-serif">Referência: <strong style="color:#ffffff">${D.periodo}</strong> &nbsp;</div>
    </td></tr></table>
  </td></tr>

  <!-- KPIs -->
  ${secHd('Resumo Executivo')}
  <tr><td style="padding:14px ${pad}px 0;background:#ffffff">
    <table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
      ${kpiCard('#00C07A','Score Médio',D.kpis.score,D.kpis.score_delta,'#00C07A')}
      ${kpiCard('#00C07A','Ativos de Dados',D.kpis.prod_ativos,D.kpis.prod_delta,'#00C07A')}
      ${kpiCard('#00C07A','Tempo médio de Entrega',D.kpis.tempo,D.kpis.tempo_delta,'#00C07A')}
      ${kpiCard('#3B6BF5','Taxa de Resolução Histórica',D.kpis.chamados+'%',D.kpis.chamados_delta,'#FF2C2C')}
      ${kpiCard('#3B6BF5','Média de Dias Chamados',D.kpis.dias_abertos_chamados,D.kpis.dias_abertos_chamados_delta,'#FF2C2C')}
      ${kpiCard('#3B6BF5','Chamados Fora do Prazo',D.kpis.chamados_aberto,D.kpis.chamados_aberto_delta,'')}
    </tr></table>
  </td></tr>

  <!-- KPI analyses — two columns -->
  <tr><td style="padding:10px ${pad}px 24px;background:#ffffff">
    <table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
      <td width="${Math.floor(inner/2)-6}" style="vertical-align:top;padding-right:6px">
        ${ana('#00C07A','#e7f9f2','Score Médio Geral',D.analises.score)}
        ${anaSpacer}
        ${ana('#00C07A','#e7f9f2','Tempo Médio de Entrega',D.analises.tempo)}
        ${anaSpacer}
        ${ana('#00C07A','#e7f9f2','Ativos de Dados',D.analises.prod)}
      </td>
      <td width="${Math.floor(inner/2)-6}" style="vertical-align:top;padding-left:6px">
        ${ana('#3B6BF5','#edf1fe','Chamados Fora do Prazo',D.analises.chamados_aberto)}
        ${anaSpacer}
        ${ana('#3B6BF5','#edf1fe','Taxa de Resolução Histórica',D.analises.chamados)}
        ${anaSpacer}
        ${ana('#3B6BF5','#edf1fe','Média de Dias Chamados',D.analises.dias_abertos_chamados)}
      </td>
    </tr></table>
  </td></tr>

  <!-- TABELA CONSOLIDADA -->
  ${secHd('Produtos com Score abaixo de 95%')}
  <tr><td style="padding:14px ${pad}px 8px;background:#ffffff">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #E2E4EA">
      <tr style="background:#F4F5F7">
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:left;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif;white-space:nowrap">Crit.</th>
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:left;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">Produto</th>
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:left;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">Área</th>
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:center;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif;white-space:nowrap">Score Abr</th>
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:center;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif;white-space:nowrap">Score Mai</th>
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:center;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif">Tend.</th>
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:center;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif;white-space:nowrap">Cham.</th>
        <th style="padding:9px 10px;font-size:8px;font-weight:700;color:#8A8FA8;text-transform:uppercase;letter-spacing:.06em;text-align:left;border-bottom:1px solid #E2E4EA;font-family:'Segoe UI',Helvetica,Arial,sans-serif;white-space:nowrap">Dim. Crítica</th>
      </tr>
      ${prodRows}
    </table>
  </td></tr>
  <!-- Table analyses below -->
  <tr><td style="padding:0 ${pad}px 24px;background:#ffffff">
    ${ana('#c01137','#f9e9ec','Distribuição por Criticidade',D.analises.tabela_crit)}
    ${anaSpacer}
    ${ana('#F5A623','#fef7ea','Análise de Desempenho e Impactos',D.analises.tabela_cham)}
    ${anaSpacer}
    ${ana('#c01137','#f9e9ec','Ações Estratégicas',D.analises.tabela_extr)}
    ${anaSpacer}
  </td></tr>

  <!-- CAUSAS — full width image, analyses below -->
  ${secHd('Causas-Raiz — Chamados '+D.periodo)}
  ${causasImg ? `
  <tr><td style="padding:14px ${pad}px 8px;background:#ffffff">
    <img src="${causasImg}" width="${inner}" style="width:100%;max-width:${inner}px;display:block;border:1px solid #E2E4EA" alt="Causas-Raiz">
  </td></tr>
  <tr><td style="padding:0 ${pad}px 24px;background:#ffffff">
    ${ana('#c01137','#f9e9ec','Destaque',D.analises.causas_conc)}
    ${anaSpacer}
    ${ana('#F5A623','#fef7ea','Solução',D.analises.causas_soluc)}
    ${anaSpacer}
  </td></tr>` : ''}

  <!-- ENTREGAS POR SQUAD -->
  ${secHd('Principais Entregas do Mês')}
  <tr><td style="padding:14px ${pad}px 24px;background:#ffffff">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      ${poRows}
    </table>
  </td></tr>

  <!-- RELEASES -->
  ${relTitle1 ? secHd(relTitle1) : secHd('Ativos de Dados — Releases '+D.periodo)}
  <tr><td style="padding:14px ${pad}px 24px;background:#ffffff">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      ${releaseRows1}
    </table>
  </td></tr>

  ${releaseRows2 ? `
  ${relTitle2 ? secHd(relTitle2) : secHd('Ativos de Dados — Releases Previstas')}
  <tr><td style="padding:14px ${pad}px 24px;background:#ffffff">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      ${releaseRows2}
    </table>
  </td></tr>` : ''}

  <!-- FOOTER — solid color, no gradient -->
  <tr><td style="background:#8C0F3B;padding:18px ${pad}px">
    <div style="font-size:13px;font-weight:700;color:#ffffff;font-family:'Segoe UI',Helvetica,Arial,sans-serif">Boletim de Qualidade de Dados — ${D.periodo}</div>
    <div style="font-size:10px;color:rgba(255,255,255,.55);margin-top:3px;font-family:'Segoe UI',Helvetica,Arial,sans-serif">· Inteligência de Dados / Bradesco</div>
  </td></tr>

</table>
</td></tr></table>
</body></html>`;
}
