/*
 * js/init.js — Ponto de entrada da aplicação
 *
 * Responsabilidade: disparar a inicialização após todos os outros scripts
 * terem sido carregados. Deve ser o último <script> em index.html.
 *
 * Conversa com:
 *   - js/ui.js (chama applyData() que preenche DOM e chama initCharts)
 *
 * Pontos importantes:
 *   - Nada além da chamada de bootstrap deve ficar aqui.
 *   - O tema é restaurado do localStorage dentro de ui.js (IIFE no final
 *     do arquivo), antes de applyData(), para evitar flash de tema errado.
 */

applyData();
